"""
event_name : custom-automations
config format:
{
    "name": "automation name",
    "automation_conf": {},
    "event_name" : "custom-automations"
}
"""

def execute_custom_automations(event):
    return True

def validate_custom_automations(event):
    return True