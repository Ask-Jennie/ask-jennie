def execute_update_urls_py(urls_py_filepath, event):
    return True

def validate_update_urls_py(event):
    return True