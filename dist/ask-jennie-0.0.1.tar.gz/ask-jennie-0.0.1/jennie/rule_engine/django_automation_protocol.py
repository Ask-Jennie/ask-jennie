class DjangoAutomationProtocol():
    def __init__(self, token):
        self.token = token

    def validate_configuration(self):
        return True

    def execute_configuration(self):
        return True